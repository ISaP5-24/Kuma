const spinButton = document.getElementById('spin-btn');
const wheel = document.getElementById('wheel');
const messageDiv = document.getElementById('message');

let totalSpins = 0; // Количество прокруток
let spinsRemaining = 0; // Оставшиеся прокрутки
let prizes = []; // Массив призов

// Функция для инициализации колеса
function initWheel() {
    totalSpins = getTotalItemsFromCart(); // Получаем количество товаров из корзины
    spinsRemaining = totalSpins;

    // Генерация призов
    generatePrizes();

    // Проверка сохраненных прокруток
    if (localStorage.getItem('spinsUsed')) {
        spinsRemaining = totalSpins - parseInt(localStorage.getItem('spinsUsed'), 10);
    }
}

// Генерация призов
function generatePrizes() {
    const uniquePrizes = new Set();
    const specialPrizes = ["Специальный 1", "Специальный 2", "Специальный 3", "Специальный 4"];

    // Добавляем обычные призы
    for (let i = 1; i <= 8; i++) {
        uniquePrizes.add(`Приз ${i}`);
    }

    // Добавляем специальные призы, если они активны
    if (isSpecialPrizesActive()) {
        specialPrizes.forEach(prize => uniquePrizes.add(prize));
    }

    // Преобразуем в массив
    prizes = Array.from(uniquePrizes);
}

// Проверка активности специальных призов
function isSpecialPrizesActive() {
    const currentDate = new Date();
    const deadline = new Date('2024-12-31'); // Установите свой дедлайн
    return currentDate < deadline;
}

// Получение количества товаров из корзины
function getTotalItemsFromCart() {
    // Здесь ваша логика получения количества товаров
    return 5; // Пример: возвращаем 5 товаров
}

// Функция вращения колеса
function spinWheel() {
    if (spinsRemaining <= 0) {
        alert("У вас больше нет прокруток!");
        return;
    }

    spinsRemaining--;
    localStorage.setItem('spinsUsed', totalSpins - spinsRemaining); // Сохраняем оставшиеся прокрутки

    const randomDegree = Math.floor(Math.random() * 360) + 360; // Один полный оборот + случайный угол
    wheel.style.transform = `rotate(${randomDegree}deg)`;

    setTimeout(() => {
        // Определяем приз на основе конечного угла
        const prizeIndex = Math.floor((randomDegree % 360) / (360 / prizes.length));
        const prize = prizes[prizeIndex];
        displayPrize(prize);
    }, 4000); // После завершения анимации
}

// Отображение сообщения о выигранном призе
function displayPrize(prize) {
    messageDiv.textContent = `Вы выиграли: ${prize}`;
}

// Обработчик события для кнопки
spinButton.addEventListener('click', spinWheel);

// Инициализация колеса при загрузке страницы
initWheel();
