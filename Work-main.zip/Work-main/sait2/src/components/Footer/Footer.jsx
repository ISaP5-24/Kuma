import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-content">
          <div className="footer-logo">КерамоМастер</div>
          <div className="footer-links">
            <a href="#home">Главная</a>
            <a href="#about">О нас</a>
            <a href="#services">Услуги</a>
            <a href="#contact">Контакты</a>
          </div>
          <div className="social-links">
            <a href="https://vk.com/ваша_группа" target="_blank" rel="noopener noreferrer" aria-label="ВКонтакте" className="social-icon vk-icon">
              <i className="fab fa-vk"></i>
            </a>
            <a href="https://t.me/KeramoMasters" target="_blank" rel="noopener noreferrer" aria-label="Telegram" className="social-icon tg-icon">
              <i className="fab fa-telegram"></i>
            </a>
            <a href="https://wa.me/+79254476875" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="social-icon wa-icon">
              <i className="fab fa-whatsapp"></i>
            </a>
          </div>
        </div>
        <div className="copyright">
          © {new Date().getFullYear()} КерамоМастер. Все права защищены.
        </div>
      </div>
    </footer>
  )
}