import { useState, useEffect } from 'react'
import './Header.css'

export default function Header({ activeSection }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  const scrollToSection = (id) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      })
    }
    setIsMobileMenuOpen(false)
  }

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <header className={`header ${isScrolled ? 'scrolled' : ''}`}>
      <div className="header-container">
        <div className="logo">КерамоМастер</div>
        
        {/* Десктопное меню */}
        <nav className="desktop-nav">
          <button 
            onClick={() => scrollToSection('home')}
            className={activeSection === 'home' ? 'active' : ''}
          >
            Главная
          </button>
          <button 
            onClick={() => scrollToSection('about')}
            className={activeSection === 'about' ? 'active' : ''}
          >
            О нас
          </button>
          <button 
            onClick={() => scrollToSection('services')}
            className={activeSection === 'services' ? 'active' : ''}
          >
            Услуги
          </button>
          <button 
            onClick={() => scrollToSection('contact')}
            className={activeSection === 'contact' ? 'active' : ''}
          >
            Контакты
          </button>
        </nav>
        
        {/* Мобильное меню */}
        <button 
          className="mobile-menu-button"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Меню"
        >
          <span className={`bar ${isMobileMenuOpen ? 'open' : ''}`}></span>
          <span className={`bar ${isMobileMenuOpen ? 'open' : ''}`}></span>
          <span className={`bar ${isMobileMenuOpen ? 'open' : ''}`}></span>
        </button>
        
        {/* Мобильное меню (выпадающее) */}
        <div className={`mobile-menu ${isMobileMenuOpen ? 'open' : ''}`}>
          <button 
            onClick={() => scrollToSection('home')}
            className={activeSection === 'home' ? 'active' : ''}
          >
            Главная
          </button>
          <button 
            onClick={() => scrollToSection('about')}
            className={activeSection === 'about' ? 'active' : ''}
          >
            О нас
          </button>
          <button 
            onClick={() => scrollToSection('services')}
            className={activeSection === 'services' ? 'active' : ''}
          >
            Услуги
          </button>
          <button 
            onClick={() => scrollToSection('contact')}
            className={activeSection === 'contact' ? 'active' : ''}
          >
            Контакты
          </button>
        </div>
      </div>
    </header>
  )
}