import './About.css'

export default function About({ id }) {
  return (
    <section id={id} className="about-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">О нашей компании</h2>
          <p className="section-subtitle">Наша история и ценности</p>
        </div>
        
        <div className="about-content">
          <div className="about-text">
            <p>
              Мы - команда профессионалов, работающая на рынке с 2010 года. 
              Наша миссия - создавать качественные цифровые продукты, которые 
              помогают бизнесу расти и развиваться.
            </p>
            <p>
              Мы сочетаем креативный подход с техническим совершенством, чтобы 
              достичь наилучших результатов для наших клиентов.
            </p>
          </div>
          
          <div className="about-stats">
            <div className="stat-item">
              <div className="stat-number">10+</div>
              <div className="stat-label">Лет опыта</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">200+</div>
              <div className="stat-label">Проектов</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">50+</div>
              <div className="stat-label">Клиентов</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}