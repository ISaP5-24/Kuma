import './Contact.css'
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaClock } from 'react-icons/fa'

export default function Contact({ id }) {
  return (
    <section id={id} className="contact-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Контакты</h2>
          <p className="section-subtitle">Свяжитесь с нами удобным для вас способом</p>
        </div>
        
        <div className="contact-cards">
          <div className="contact-card">
            <div className="card-icon">
              <FaPhone className="icon" />
            </div>
            <h3 className="card-title">Телефон</h3>
            <a href="tel:+79254476875" className="card-link">+7 (925) 447-68-75</a>
            <p className="card-description">Звоните с 9:00 до 20:00 ежедневно</p>
          </div>

          <div className="contact-card">
            <div className="card-icon">
              <FaEnvelope className="icon" />
            </div>
            <h3 className="card-title">Email</h3>
            <a href="mailto:metelev.astra@yandex.ru" className="card-link">metelev.astra@yandex.ru</a>
            <p className="card-description">Ответим в течение рабочего дня</p>
          </div>

          <div className="contact-card">
            <div className="card-icon">
              <FaMapMarkerAlt className="icon" />
            </div>
            <h3 className="card-title">Адрес</h3>
            <p className="card-address">г. Москва, ул. Строителей, 15, офис 304</p>
            <a 
              href="https://yandex.ru/maps/-/CDuQvCvD" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="map-link"
            >
              Посмотреть на карте →
            </a>
          </div>

          <div className="contact-card">
            <div className="card-icon">
              <FaClock className="icon" />
            </div>
            <h3 className="card-title">Режим работы</h3>
            <div className="work-schedule">
              <p className="work-hours"><span>Пн-Пт:</span> 9:00 - 18:00</p>
              <p className="work-hours weekend"><span>Сб:</span> выходной</p>
              <p className="work-hours weekend"><span>Вс:</span> выходной</p>
            </div>
          </div>
        </div>

        <div className="social-section">
          <h3 className="social-title">Мы в соцсетях</h3>
          <p className="social-subtitle">Подпишитесь для получения полезной информации</p>
          
          <div className="social-links">
            <a href="https://vk.com/ваша_группа" target="_blank" rel="noopener noreferrer" aria-label="ВКонтакте" className="social-icon vk-icon">
              <i className="fab fa-vk"></i>
            </a>
            <a href="https://t.me/KeramoMasters" target="_blank" rel="noopener noreferrer" aria-label="Telegram" className="social-icon tg-icon">
              <i className="fab fa-telegram"></i>
            </a>
            <a href="https://wa.me/+79254476875" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="social-icon wa-icon">
              <i className="fab fa-whatsapp"></i>
            </a>
          </div>
          </div>
        </div>
       
    </section>
  )
}