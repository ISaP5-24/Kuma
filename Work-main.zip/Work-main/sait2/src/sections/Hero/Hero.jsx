import './Hero.css'

export default function Hero({ id }) {
  return (
    <section id={id} className="hero-section">
      <div className="hero-content">
        <h1 className="hero-title">Профессиональный монтаж крупноформатного керамогранита</h1>
        <p className="hero-subtitle">Безупречное качество работ с гарантией 10 лет</p>
        <div className="hero-buttons">
          <button 
            className="hero-button primary"
            onClick={() => document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })}
          >
            Бесплатный замер
          </button>
          <button 
            className="hero-button secondary"
            onClick={() => document.getElementById('services').scrollIntoView({ behavior: 'smooth' })}
          >
            Наши услуги
          </button>
        </div>
      </div>
      <div className="hero-scroll-indicator">
        <div className="scroll-circle"></div>
      </div>
    </section>
  )
}