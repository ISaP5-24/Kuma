import './Services.css'

export default function Services({ id }) {
  const services = [
    {
      title: "Подъем керамогранита",
      description: "Подъем крупноформатного керамогранита на этажи без повреждений с использованием профессионального оборудования",
      icon: "🏗️",
      price: "от 1000 ₽/шт."
    },
    {
      title: "Резка керамогранита",
      description: "Заусовка под углом 45°, сверление отверстий и вырезов. Раскрой на профессиональном оборудовании",
      icon: "✂️",
      price: "от 500 ₽/п.м."
    },
    {
      title: "Монтаж керамогранита",
      description: "Монтаж на полы и стены с соблюдением ГОСТов и СНиПов",
      icon: "🛠️",
      price: "от 3000 ₽/м²"
    }
  ];

  const priceList = [
    { category: "Монтаж крупноформатного керамогранита", items: [
      { name: "Плитка 120*60", price: "от 3000 ₽/м²" },
      { name: "Плитка 120*120", price: "от 3500 ₽/м²" },
      { name: "Плитка 100*300", price: "от 4500 ₽/м²" },
      { name: "Плитка 120*260", price: "от 4500 ₽/м²" },
      { name: "Плитка 120*280", price: "от 4500 ₽/м²" },
      { name: "Плитка 150*300", price: "от 5500 ₽/м²" },
      { name: "Плитка 160*320", price: "от 8000 ₽/м²" }
    ]},
    { category: "Облицовка за погонный метр", items: [
      { name: "Облицовка мебели, откосов", price: "от 3500 ₽" },
      { name: "Откосы, простенки коробов, бордюры", price: "от 2400 ₽" }
    ]},
    { category: "Угол 45 градусов", items: [
      { name: "В сборе с запилом (заусовка)", price: "от 2000 ₽/п.м." }
    ]},
    { category: "Резка плиты", items: [
      { name: "Разрез плиты", price: "от 500 ₽/п.м." },
      { name: "Чистый видимый рез с доработкой", price: "от 1000 ₽/п.м." },
      { name: "Г-образный рез", price: "от 2000 ₽/п.м." },
      { name: "П-образный рез", price: "от 3000 ₽/п.м." }
    ]},
    { category: "Сверление отверстий", items: [
      { name: "Отверстия до 69 мм", price: "от 700 ₽/шт." },
      { name: "Отверстия более 70 мм", price: "от 1000 ₽/шт." }
    ]},
    { category: "Затирка швов", items: [
      { name: "Цементными составами", price: "от 500 ₽/п.м." },
      { name: "Двухкомпонентными составами", price: "от 700 ₽/п.м." },
      { name: "Формирование наружных углов", price: "от 2000 ₽/п.м." }
    ]},
    { category: "Душевой поддон", items: [
      { name: "Устройство с трапом и гидроизоляцией", price: "от 15000 ₽" },
      { name: "Облицовка плиткой", price: "от 15000 ₽" }
    ]},
    { category: "Подготовка", items: [
      { name: "Грунтовка", price: "от 100 ₽/м²" },
      { name: "Гидроизоляция в два слоя", price: "от 600 ₽/м²" },
      { name: "Гидроизоляционная лента", price: "от 150 ₽/п.м." }
    ]},
    { category: "Реставрация", items: [
      { name: "Реставрация керамогранита", price: "от 10000 ₽" }
    ]}
  ];

  return (
    <section id={id} className="services-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Наши услуги</h2>
          <p className="section-subtitle">Профессиональная работа с керамогранитом любого формата</p>
          <div className="price-notice">
            <p>Минимальный заказ по Москве и Московской области <strong>от 30 000 ₽</strong></p>
          </div>
        </div>
        
        <div className="services-grid">
          {services.map((service, index) => (
            <div className="service-card hover-scale" key={index}>
              <div className="service-icon">{service.icon}</div>
              <h3 className="service-title">{service.title}</h3>
              <p className="service-description">{service.description}</p>
              <div className="service-price">{service.price}</div>
              <button 
                className="service-button"
                onClick={() => document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })}
              >
                Заказать услугу →
              </button>
            </div>
          ))}
        </div>

        <div className="price-list-section">
          <h3 className="price-list-title">Прайс-лист на услуги</h3>
          <p className="price-list-subtitle">Актуальные цены на установку и обработку керамогранита</p>
          
          <div className="price-list-container">
            {priceList.map((category, catIndex) => (
              <div className="price-category" key={catIndex}>
                <h4 className="category-title">{category.category}</h4>
                <div className="price-items">
                  {category.items.map((item, itemIndex) => (
                    <div className="price-item" key={itemIndex}>
                      <span className="item-name">{item.name}</span>
                      <span className="item-price">{item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}